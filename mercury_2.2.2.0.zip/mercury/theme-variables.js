/*
 * Custom function used to generate the output of the theme variables
 */

var generateThemeVariables = function(params) {
   let output = '';

      output += ` 
         :root {
            --page-margin:        ${params.pageMargin};
            --page-width:         ${params.pageWidth}; 
            --entry-width:        ${params.entryWidth}; 
            --header-height:      4rem; 
            --border-radius:      2px;
            --grid-gap:           ${params.gridGap}rem; 
            --font-weight-normal: ${params.fontNormalWeight}; 
            --font-weight-bold:   ${params.fontBoldWeight}; 
            --line-height:        ${params.lineHeight}; 
            --headings-weight:    ${params.fontHeadignsWeight};
            --headings-transform: ${params.fontHeadingsTransform};
            --white:              #FFFFFF;
            --black:              #000000;
            --dark:               #111111;
            --gray-1:             #686868;
            --gray-2:             #888888;
            --light:              #D5D5D5;
            --lighter:            #F5F5F5;
            --color:              ${params.primaryColor};   
            --color-rgb:          ${params.primaryColor.replace('#', '').match(/[a-f0-9]{2,2}/gmi).map(n => parseInt(n, 16)).join(', ')};
            --text-color:         ${params.textColor};   
            --headings-color:     ${params.headingsColor};  
         }
         
         @media all and (min-width: 56.25em) {
            :root {
               --header-height: ${params.navbarHeight};
            }
      }`;  

   return output;
}

module.exports = generateThemeVariables;